VIRUS PRANK - PROYECTO ANDROID

Este proyecto es una broma visual. No contiene malware, no solicita permisos,
no analiza archivos y no modifica el teléfono.

CÓMO GENERAR EL APK:
1. En una computadora, instala Android Studio.
2. Descomprime VirusPrank.zip.
3. En Android Studio elige Open y selecciona la carpeta VirusPrank.
4. Espera a que termine la sincronización de Gradle.
5. Ve a Build > Build Bundle(s) / APK(s) > Build APK(s).
6. Android Studio mostrará un aviso para localizar el APK generado.

Para probarlo en un teléfono, transfiere el APK generado y ábrelo.
Instala únicamente APKs que tú mismo hayas compilado y revisado.

Nombre de la app: Virus Prank
Paquete: com.example.virusprank
Permisos: ninguno
